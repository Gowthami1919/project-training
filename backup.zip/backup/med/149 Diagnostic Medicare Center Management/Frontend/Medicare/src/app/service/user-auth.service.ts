import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {
  loggedIn = false;
  userId: number;
  token: string;
  role: string;
  user: string;
  isAdd :boolean;
  isEdit:boolean;
  loggedInUser
  rejectedUser
  getnotify:boolean;
  appoNotifyList:any;
  constructor() { }

  isLoggedIn() {
    return this.loggedIn;
  }
  getIsAdded() {
    return this.isAdd;
  }
  setIsEdited(isEdit: boolean) {
    this.isEdit = isEdit;
  }
  getIsEdited() {
    return this.isEdit;
  }

  setIsAdded(isAdd: boolean) {
    this.isAdd = isAdd;
  }
  setLoggedIn(loggedIn: boolean) {
    this.loggedIn = loggedIn;
    console.log("Auth service");
    console.log(this.loggedIn)
  }

  public logout() {
    this.loggedIn = false;
  }

  public setRole(role: string) {
    this.role = role;
    console.log(role);
  }

  public getRole() {
    return this.role;
 }
 
}
