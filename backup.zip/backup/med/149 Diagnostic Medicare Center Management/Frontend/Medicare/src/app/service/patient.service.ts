import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Patient } from '../patient/patient/patient';
import { AuthenticationService } from './authentication.service';
import { UserAuthService } from './user-auth.service';
import { BookAppointment } from '../patient/patient/book-appoitment';
import { environment } from 'src/environments/environment';
import { Bookdoc } from '../patient/bookdoc';
import { User } from '../site/User';
import { Medicare } from '../admin/medicare';
import { TestReport } from '../admin/TestReport';
import { FormGroup } from '@angular/forms';


@Injectable({
  providedIn: 'root'
})
export class PatientService {
  baseUrl = environment.baseUrl+'patient';
  AdminUrl = environment.baseUrl+'admin';
  patientApproval: boolean;
  constructor(private httpClient: HttpClient, private authenticationService: AuthenticationService, private userAuthService: UserAuthService) { }

  addPatient(patient: Patient): Observable<Patient> {
    console.log("FROM USER SERVICE -> " + patient)

    return this.httpClient.post<Patient>(this.baseUrl,
     patient,
     {
       headers:new HttpHeaders({
      'Content-Type': 'application/json',
      
    })
  });
  
  }
  getReports():Observable<TestReport[]>
  {
    const httpOptions={
      headers: new HttpHeaders({
        'Content-Type':'application/json',
        'responseType': 'text'
      })
     
    };
    
    return this.httpClient.get<TestReport[]>(this.AdminUrl+"/TestResults",httpOptions);
  }
  getReportDetails(patientid:number):Observable<TestReport>
  {
    const httpOptions={
      headers: new HttpHeaders({
        'Content-Type':'application/json',
        'responseType': 'text'
      })
     
    };
    return this.httpClient.get<TestReport>(this.AdminUrl+"/TestResults/"+patientid,httpOptions);
  }
  updateReportdetails(id:number,edittestresult:any):Observable<TestReport>
  {
    var body= JSON.stringify(edittestresult.value)
console.log(body);
    const httpOptions={
      headers: new HttpHeaders({
        'Content-Type':'application/json',
        'responseType': 'text'
      })
     
    };
    return this.httpClient.put<TestReport>(this.AdminUrl+"/UpdateTest/"+id,body,httpOptions);
  }
  getAllUserPatients():Observable<any[]>
  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'})
    };
  return this.httpClient.get<any[]>(this.AdminUrl+"/patientrequest",httpOptions);

  }
  getAllUserPatientsDetails(id:Number):Observable<User>

  {
    let data =id;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'responseType': 'text'
      })
    };
    console.log("hello");

  return this.httpClient.get<any>(this.AdminUrl+"/Viewpatientrequest/"+id,httpOptions);
  } 

  AcceptPatients(id:number):Observable<User[]>
  {
    let data = id
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
        
      })
    };
    console.log(id);
    return this.httpClient.put<User[]>(this.AdminUrl+"/PaAccept/"+data,httpOptions);
  }

  deleteNewPatient(id:number,comments:string):Observable<User[]> {
    let data=id+"/"+comments
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
       
      })
    };
    return this.httpClient.put<User[]>(this.AdminUrl+"/PaDecline/"+data,httpOptions);
  }
  getAllPatientsRequests():Observable<any>
  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
        
      })
    };

  return this.httpClient.get<any>(this.AdminUrl+"/patientrequest",httpOptions);

  }

getservicesavailble():Observable<any[]>
{
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
      
    })
  };

return this.httpClient.get<any>(this.baseUrl+"/Medicalservicelist",httpOptions);
}
getALLservicesavailble(id:number):Observable<any[]>
{
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
      
    })
  };

return this.httpClient.get<any>(this.baseUrl+"/Medicalservicelist/"+id,httpOptions);
}
GetAllDoctorsAvailble(serviceId:number):Observable<any>
{
  const httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
      
    })
  };
  return this.httpClient.get<any>(this.baseUrl+"/DisplayDoctordetails/"+serviceId,httpOptions);
}
GetServicedetailsofDoctorAvail(doctorid:number):Observable<any[]>
{
  const httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
      
    })
  };
  return this.httpClient.get<any[]>(this.baseUrl+"/DoctorDetailswithmediservice/"+doctorid,httpOptions);
}
GetBookappoFormDetails(serviceid:number,doctorid:number):Observable<any>
{
  var data=serviceid+"/"+doctorid;
  const httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
      
    })
  };
  return this.httpClient.get<TestReport>(this.baseUrl+"/GetServiceDetailsById/"+data,httpOptions);
}
BookAppoSave(medid:any,docid:any,formvalues:any):Observable<TestReport>
  {
    var body= JSON.stringify(formvalues.value)
    var data=medid+"/"+docid;
console.log(body);
    const httpOptions={
      headers: new HttpHeaders({
        'Content-Type':'application/json',
        'responseType': 'text'
      })
     
    };
    return this.httpClient.post<TestReport>(this.baseUrl+"/bookappointment/"+data,body,httpOptions);
  }
  checkappointmentstatus(patID:number):Observable<any[]>
  {
    const httpOptions={
      headers: new HttpHeaders({
        'Content-Type':'application/json',
        'responseType': 'text'
      })
     
    };
    return this.httpClient.get<any[]>(this.baseUrl+"/AppoStatus/"+patID,httpOptions);
  }
  checkTestReportStatus(PatId:number):Observable<any[]>
  {
    const httpOptions={
      headers: new HttpHeaders({
        'Content-Type':'application/json',
        'responseType': 'text'
      })
     
    };
    return this.httpClient.get<any[]>(this.baseUrl+"/TestStatus/"+PatId,httpOptions);
  }
RaiseTestRequest(patId:any):Observable<any[]>

{
  const httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json',
      'responseType': 'text'
    })
   
  };
  return this.httpClient.put<any[]>(this.baseUrl+"/paTestRequest/"+patId,httpOptions);
}
CheckEmail(email:string):Observable<any>
{
  const httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json',
      'responseType': 'text'
    })
   
  };
  return this.httpClient.get<any>(this.baseUrl+"/CheckUser/"+email,httpOptions);
}
}
