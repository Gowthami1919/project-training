﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MedicareEF.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MedicareEF.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        MedicareContext medicontext = new MedicareContext();

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(medicontext.);
        }
    }
}