﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MedicareEF.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MedicareEF.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        MedicareContext MediContext = new MedicareContext();
        Patient pt = new Patient();
        [HttpPost]
        public IActionResult create([FromBody] Patient patient )
        {
            pt.PtFirstName = patient.PtFirstName;
            pt.PtLastName = patient.PtLastName;
            pt.PtAge = patient.PtAge;
            pt.PtGender = patient.PtGender;
            pt.PtDob = patient.PtDob;
            pt.PtContactNumber = patient.PtContactNumber;
            pt.PtAltNumber = patient.PtAltNumber;
            pt.PtEmail = patient.PtEmail;
            pt.PtPassword = patient.PtPassword;
            pt.PtAddress1 = patient.PtAddress1;
            pt.PtAddress2 = patient.PtAddress2;
            pt.PtCity = patient.PtCity;
            pt.PtState = patient.PtState;
            pt.PtZipCode = patient.PtZipCode;
            MediContext.Add(pt);
            MediContext.SaveChanges();
            return Ok("details are saved");
        }
        [HttpGet]
        public IActionResult get()
        {
            return Ok(MediContext.Patient);
        }

    }
}