﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace MedicareEF.Controllers
{
    [EnableCors("MedicarePolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        public IConfiguration Configuration { get; }
        public AuthenticationController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            if (id == "Admin")
            {
                return Ok(GenerateToken("Admin"));
            }
            else if (id == "Doctor")
            {
                return Ok(GenerateToken("Doctor"));
            }
            else
            {
                return Ok(GenerateToken("Patient"));
            }
        }
        private string GenerateToken(string userRole)
        {
            var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["JWT:ServerSecret"]));
            var credentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Role, userRole)
            };
            var token = new JwtSecurityToken(issuer: Configuration["JWT:Issuer"], audience: Configuration["JWT:audience"],
                claims: claims, expires: DateTime.Now.AddHours(1), signingCredentials: credentials);
            return new JwtSecurityTokenHandler().WriteToken(token);

        }

    }
}