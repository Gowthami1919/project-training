import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Doctor } from '../doctor/doctor/doctor';
import { UserAuthService } from './user-auth.service';
import { Medicare } from '../admin/medicare';
import { BookAppointment } from '../patient/patient/book-appoitment';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { createOfflineCompileUrlResolver } from '@angular/compiler';


@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  baseUrl = environment.baseUrl+'doctor';
  adminUrl = environment.baseUrl+'admin';
  patientLength = 0;
  doctorApproval:boolean;

  constructor(private httpClient: HttpClient, private userAuthService: UserAuthService, private route: Router) { }

  addDoctor(doctor: Doctor): Observable<Doctor> {
   
    console.log("FROM USER SERVICE -> " + doctor)
    return this.httpClient.post<Doctor>(this.baseUrl, doctor,
      {
        
        headers:new HttpHeaders({
          'Content-Type': 'application/json',
          
        })
       
      });
}
  getAllUserDoctors():Observable<any[]>
  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',})
    };
    return this.httpClient.get<any[]>(this.adminUrl+"/Doctorrequest",httpOptions);
  }
  getAllDoctorDetails(doctorId: number): Observable<Doctor>  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json', 'responseType': 'text'})
    };
    return this.httpClient.get<Doctor>(this.adminUrl+"/ViewDoctorrequest/"+ doctorId, httpOptions);
  }
  rejectDoctor(id:number,message:any):Observable<any>
  {
    let data=id+"/"+message;
 
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
       
      })
    };
  
    return this.httpClient.put<any>(this.adminUrl+"/DocDecline/"+data,httpOptions);
  }
  approveDoctor(id:number):Observable<Doctor>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        
      })
    };

    return this.httpClient.put<Doctor>(this.adminUrl+"/DocAccept/"+id,{},httpOptions);
  }
  PenidngDoctor(id:number):Observable<Doctor>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        
      })
    };

    return this.httpClient.put<Doctor>(this.adminUrl+"/DocPending/"+id,{},httpOptions);
  }
  getAllMedServices():Observable<any[]>
  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',})
    };
    return this.httpClient.get<any[]>(this.baseUrl+"/DoctorService",httpOptions);
  }

PatientRequest(doctor_id:number):Observable<any[]>
  {
    
    const httpOptions={
      headers:new HttpHeaders({
        'Content-Type': 'application/json',
        'responseType': 'text'
      })
    };
    return this.httpClient.get<any[]>(this.baseUrl+"/PatientRequest/"+doctor_id,httpOptions);
  }

patientAccept(Book_Id:number):Observable<any[]>
  {
    const httpOptions={
      headers:new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };
    return this.httpClient.put<any[]>(this.baseUrl+"/DoctorApproval/"+Book_Id,httpOptions);
  }
  patientReject(Book_Id:number):Observable<any[]>
  {
    const httpOptions={
      headers:new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };
    return this.httpClient.put<any[]>(this.baseUrl+"/DoctorReject/"+Book_Id,httpOptions);
  }

  getPatientReports(Doctor_Id:number):Observable<any[]>
  {
    const httpOptions={
      headers :new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };
    return this.httpClient.put<any[]>(this.baseUrl+"/PatientReports/"+Doctor_Id,httpOptions);
  }
  UploadPatientTestReports(form:any):Observable<any>
  {
    var body= JSON.stringify(form.value)
    console.log(body);
    console.log("came into upload test report")
        const httpOptions={
          headers: new HttpHeaders({
            'Content-Type':'application/json',
            'responseType': 'text'
          })
         
        };
        return this.httpClient.post<any>(this.baseUrl+"/PostTestResult/",body,httpOptions);
    
  }
  getAlldoctorServices(Doctor_Id:Number):Observable<any[]>
  {
  const httpOptions={
    headers: new HttpHeaders({
      'Content-Type':'application/json',
      'responseType': 'text'
    })
   
  };
  return this.httpClient.get<any[]>(this.baseUrl+"/GetAllServices/"+Doctor_Id,httpOptions);
  }
  AddServiceToDoctor( service_id:number,doctor_id:number ):Observable<any[]>

  {
    console.log("Addervice");
    let data=service_id+"/"+doctor_id;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json', 'responseType': 'text'})
    };
    return this.httpClient.post<any[]>(this.baseUrl+"/AddServiceToDoctor/"+data,httpOptions);
  }

  deleteServiceFromDoctor(doctor_id:number,service_id:number):Observable<any>
  {
    console.log("Delete Service");
    let data=doctor_id+"/"+service_id;
    console.log(data);
    const httpOptions={
      headers:new HttpHeaders({
        
    'Content-Type': 'application/json', 'responseType': 'text'})
  };
  return this.httpClient.delete<any>(this.baseUrl+"/DeleteDoctorServices/"+data,httpOptions);

  }
  CheckEmail(email:string):Observable<any>
  {
    const httpOptions={
      headers:new HttpHeaders({
        'Content-Type':'application/json',
        'responseType': 'text'
      })
     
    };
    return this.httpClient.get<any>(this.baseUrl+"/checkUsername/"+email,httpOptions);
  }



}