import { Component, OnInit } from '@angular/core';
import { DoctorService } from 'src/app/service/doctor.service';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { Router } from '@angular/router';
import { PatientService } from 'src/app/service/patient.service';

@Component({
  selector: 'app-appointmentsrequests',
  templateUrl: './appointmentsrequests.component.html',
  styleUrls: ['./appointmentsrequests.component.css']
})
export class AppointmentsrequestsComponent implements OnInit {
  AllpatientRequest: any[];
  AllpatientReports: any[];
  MyServices: any;
  patients: any;

  constructor(private doctorService: DoctorService,  private userAuthService: UserAuthService, private router: Router,private patientService:PatientService ) { }
  ngOnInit() {
console.log(this.userAuthService.loggedInUser[0]['doctorId'])
    this.doctorService.PatientRequest(this.userAuthService.loggedInUser[0]['doctorId']).subscribe(data=>{
      this.AllpatientRequest=data;
     console.log(this.AllpatientRequest);})
      this.doctorService.getPatientReports(this.userAuthService.loggedInUser[0]['doctorId']).subscribe(data=>{
        this.AllpatientReports=data;
        console.log(this.AllpatientReports);})
        this.doctorService.getAlldoctorServices(this.userAuthService.loggedInUser[0]['doctorId']).subscribe(data=>{
          this.MyServices=data;
          console.log(this.MyServices);
        })
    
     
    
  }
  acceptPat(id:number)
  {
    console.log(id);
    this.doctorService.PatientRequest(this.userAuthService.loggedInUser[0]['doctorId']).subscribe(data=>{
      this.AllpatientRequest=data;
      console.log(this.AllpatientRequest); 
    });
    console.log(id);
      this.doctorService.patientAccept(id).subscribe(data=>{
        this.patients=data;
        console.log(this.patients);
      })
      this.doctorService.PatientRequest(this.userAuthService.loggedInUser[0]['doctorId']).subscribe(data=>{
        this.AllpatientRequest=data;
        console.log(this.AllpatientRequest); 
      });
  }
  
  deleteReq(id:number)
  {
    this.doctorService.PatientRequest(this.userAuthService.loggedInUser[0]['doctorId']).subscribe(data=>{
      this.AllpatientRequest=data;
      console.log(this.AllpatientRequest); 
    });
    console.log(id);
    this.doctorService.patientReject(id).subscribe(data=>{ 
      this.patients=data;
      console.log(this.patients);
    })
    this.doctorService.PatientRequest(this.userAuthService.loggedInUser[0]['doctorId']).subscribe(data=>{
      this.AllpatientRequest=data;
      console.log(this.AllpatientRequest); 
    });
  }
}
