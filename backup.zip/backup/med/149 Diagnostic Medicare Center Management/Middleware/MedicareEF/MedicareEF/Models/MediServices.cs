﻿using System;
using System.Collections.Generic;

namespace MedicareEF.Models
{
    public partial class MediServices
    {
        public MediServices()
        {
            Doctor = new HashSet<Doctor>();
        }

        public int MdId { get; set; }
        public string MdService { get; set; }
        public string MdDescription { get; set; }
        public long MdAmount { get; set; }

        public virtual ICollection<Doctor> Doctor { get; set; }
    }
}
