import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PatientService } from 'src/app/service/patient.service';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-bookappointment',
  templateUrl: './bookappointment.component.html',
  styleUrls: ['./bookappointment.component.css']
})
export class BookappointmentComponent implements OnInit {

  editTestsForm:FormGroup = this.formBuilder.group({
    'patientId':new FormControl("",[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
          'patientName':new FormControl("",[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
          
          'username':new FormControl(this.userauthservice.loggedInUser.username,[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
          'age':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
          'doctorId':new FormControl(""),
          'doctorName':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
          'amount': new FormControl("",[Validators.required]),
          'email':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
          'slotBooking': new FormControl("",[Validators.required]),
          'speciality': new FormControl("",[Validators.required,Validators.email]),
          'serviceId':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
          'appoDate': new FormControl("",[Validators.required]),
   
  });
  submitted = false;
  docid:any;
  medid:any;
 ServiceDetails
  type:string;
  message:string;
  success:boolean;
  userdetails:any;
  dateStart = new Date()
minStartDate = this.datepipe.transform(this.dateStart, 'yyyy-MM-dd')

  constructor( private route: ActivatedRoute,private userauthservice:UserAuthService ,private formBuilder:FormBuilder ,private patientservice:PatientService,private router:Router, private datepipe:DatePipe) { }

  ngOnInit() {

    console.log(this.userauthservice.loggedInUser);
    // this.editTestsForm = this.formBuilder.group({
    //   'PatientName':new FormControl("",[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
    //   'Username':new FormControl("",[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
    //   'Age':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
    //   'firstName':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
    //   'speciality': new FormControl("",[Validators.required,Validators.email]),
    //   'mdService': new FormControl("",[Validators.required,Validators.email]),
    //   'mdAmount':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
    //   'mdDescription': new FormControl("",[Validators.required])
     
    // })
   
    this.medid = this.route.snapshot.paramMap.get('id');
    this.docid = this.route.snapshot.paramMap.get('docid');
    console.log(this.docid)
   console.log( this.medid); 
this.userdetails=this.userauthservice.loggedInUser;
console.log(this.userdetails);
    this.ServiceDetails =this.patientservice.GetBookappoFormDetails(this.medid,this.docid);
    this.patientservice.GetBookappoFormDetails(this.medid,this.docid).subscribe(
      data=>{
        console.log(data)
        this.editTestsForm = this.formBuilder.group({
          'patientId':new FormControl(this.userdetails[0].patientId,[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
          'patientName':new FormControl("",[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
          'username':new FormControl(this.userdetails[0].firstName,[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
          'age':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
           'doctorName':new FormControl(data[0]['firstName'],[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
          'amount': new FormControl(data[0]['mdAmount'],[Validators.required]),
           'email':new FormControl(this.userdetails[0].emailId,[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
          'slotBooking': new FormControl(data[0]['workHours'],[Validators.required]),
          'speciality': new FormControl(data[0]['mdService'],[Validators.required]),
          'appoDate': new FormControl("",[Validators.required]),
        })
      })
console.log(this.userauthservice.loggedInUser);
      
  }
  Admindetails()
  {
    return this.userauthservice.loggedInUser  
    
  }
  get f(){
    return this.editTestsForm.controls;
  }
  const 
  BookAppo(){

    console.log("juhgjh"); 
    this.patientservice.BookAppoSave(this.medid,this.docid,this.editTestsForm).subscribe(
      data => {
        console.log(data)
        var message=JSON.parse(JSON.stringify(data))['message']; 
      
        if(JSON.parse(JSON.stringify(data))['message']==message)
        {
        this.router.navigateByUrl("patient");
        alert('SUCCESSFULLY Updated');
        }
        
else{
  alert('Update Again ');
}
      });
  }
}
