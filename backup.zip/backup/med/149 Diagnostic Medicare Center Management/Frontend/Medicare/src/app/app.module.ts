import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DoctorComponent } from './doctor/doctor/doctor.component';
import { LoginComponent } from './site/login/login.component';
import { SignupComponent } from './site/signup/signup.component';
import { HeaderComponent } from './site/header/header.component';
import { AdminComponent } from './admin/admin/admin.component';
import { PatientComponent } from './patient/patient/patient.component';
import { AllowLoginComponent } from './allow-login/allow-login.component';
import { ContactusComponent } from './contactus/contactus.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { DatePipe } from '@angular/common';
import { NgImageSliderModule } from 'ng-image-slider';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FooterComponent } from './footer/footer/footer.component';
import {HttpClientInMemoryWebApiModule} from 'angular-in-memory-web-api';
import { InMemoryDataService } from './in-memory-data.service';
import { NgxPageScrollModule } from 'ngx-page-scroll';
import { DailogComponent } from './admin/dailog/dailog.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BookappointmentComponent } from './patient/bookappointment/bookappointment.component';
import { NotificationsComponent } from './patient/notifications/notifications.component';
import { ProfilecomponentComponent } from './patient/profilecomponent/profilecomponent.component';
import { AddserviceComponent } from './doctor/addservice/addservice.component';
import { MyservicesComponent } from './doctor/myservices/myservices.component';
import { UploadtestsComponent } from './doctor/uploadtests/uploadtests.component';
import { AppointmentsrequestsComponent } from './doctor/appointmentsrequests/appointmentsrequests.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    DoctorComponent,
    PatientComponent,
    HeaderComponent,
    AdminComponent,
    
    AllowLoginComponent,
    ContactusComponent,
   
    FooterComponent, DailogComponent, BookappointmentComponent, NotificationsComponent, ProfilecomponentComponent, AddserviceComponent, MyservicesComponent, UploadtestsComponent, AppointmentsrequestsComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    NgImageSliderModule,
    BrowserAnimationsModule,
    BrowserModule,
    NgxPageScrollModule,
    HttpClientModule,

     NgbModule 
    // HttpClientInMemoryWebApiModule.forRoot(
    //   InMemoryDataService,
    //   {
    //     dataEncapsulation:false
    //   }
    // )



  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
