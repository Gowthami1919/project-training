import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserAuthService } from './user-auth.service';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClientModule } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  authenticationApiUrl = environment.baseUrl+'authentication';
 BaseUrl=environment.baseUrl;
  private token: string;
  constructor( private userAuthService: UserAuthService,private http:HttpClient) { }
 Adminauthenticate(user: string, password: string): Observable<any> {
    let data =user+"/"+password;
    let headers = new HttpHeaders({'Content-Type':'application/json','Response-Type' :'Text'});
    console.log("Entered");

  
    return this.http.post(this.BaseUrl+"admin/login/"+data,headers);
    
  }
  Doctorauthenticate(user: string, password: string): Observable<any> {
    // let credentials = btoa(user + ':' + password);
    let data =user+"/"+password;
    let headers = new HttpHeaders({'Content-Type':'application/json'});
    console.log("Entered");

    
    return this.http.post(this.BaseUrl+"doctor/login/"+data,headers);
    
  }
  Patientauthenticate(user: string, password: string): Observable<any> {
    // let credentials = btoa(user + ':' + password);
    let data =user+"/"+password;
    let headers = new HttpHeaders({'Content-Type':'application/json'});
    console.log("Entered");

    return this.http.post(this.BaseUrl+"patient/login/"+data,headers);
    
  }
  

  public setToken(token: string) {
    this.token = token;
  }
  public getToken() {
    return this.token;
  }

  logOut() {
    this.userAuthService.setLoggedIn(false);
  }
}
