import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppointmentsrequestsComponent } from './appointmentsrequests.component';

describe('AppointmentsrequestsComponent', () => {
  let component: AppointmentsrequestsComponent;
  let fixture: ComponentFixture<AppointmentsrequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppointmentsrequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppointmentsrequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
