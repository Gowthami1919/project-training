import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allow-login',
  templateUrl: './allow-login.component.html',
  styleUrls: ['./allow-login.component.css']
})
export class AllowLoginComponent implements OnInit {

  images:any

public imagenames;
  public imagesUrl;
  roleAdmin:String="Admin";
  roleUser:String="Patient";
  roleDoctor:String="Doctor";

  constructor() { }

  ngOnInit() {
    this.images = ['https://images.unsplash.com/photo-1505751172876-fa1923c5c528?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
 
  'https://images.unsplash.com/photo-1566004100631-35d015d6a491?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80 ',
  'https://images.unsplash.com/photo-1517948430535-1e2469d314fe?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
  'https://images.unsplash.com/photo-1516826049371-1e7856387270?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60']
  }


}
