import { Component, OnInit } from '@angular/core';
import { DoctorService } from 'src/app/service/doctor.service';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { PatientService } from 'src/app/service/patient.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-myservices',
  templateUrl: './myservices.component.html',
  styleUrls: ['./myservices.component.css']
})
export class MyservicesComponent implements OnInit {
  AllpatientRequest: any[];
  MyServices: any[];
  AllpatientReports: any;
myservice:Observable<any[]>
  constructor(private doctorService: DoctorService, private userAuthService: UserAuthService, private router: Router,private patientService:PatientService ) { }

  ngOnInit() {
    console.log("patientrequesyt");
    // this.doctorService.PatientRequest(this.userAuthService.loggedInUser[0].doctorId).subscribe(data=>{
    //   this.AllpatientRequest=data;
    //  console.log(this.AllpatientRequest);
    // });
    //   this.doctorService.getPatientReports(this.userAuthService.loggedInUser[0].doctorId).subscribe(data=>{
    //     this.AllpatientReports=data;
    //     console.log(this.AllpatientReports);
    //   })
        this.doctorService.getAlldoctorServices(this.userAuthService.loggedInUser[0].doctorId).subscribe(data=>{
          this.MyServices=data;
          console.log(this.MyServices);
        })
        // this.myservice=this.doctorService.getAlldoctorServices(this.userAuthService.loggedInUser[0].doctorId);


}

 

DeletemyServices(Service_id:number){

  
  this.doctorService.deleteServiceFromDoctor(this.userAuthService.loggedInUser[0].doctorId,Service_id).subscribe(data=>{
    
    this.doctorService.getAlldoctorServices(this.userAuthService.loggedInUser[0].doctorId).subscribe(data=>{
      this.MyServices=data;
      console.log(this.MyServices);
     
    })
  })
  

}
    }
  
