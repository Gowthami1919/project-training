﻿using System;
using System.Collections.Generic;

namespace MedicareEF.Models
{
    public partial class Admin
    {
        public int AdId { get; set; }
        public string AdFirstName { get; set; }
        public string AdLastName { get; set; }
        public short AdAge { get; set; }
        public string AdGender { get; set; }
        public DateTime AdDob { get; set; }
        public long AdContactNumber { get; set; }
        public long? AdAltNumber { get; set; }
        public string AdEmailId { get; set; }
        public string AdPassword { get; set; }
        public string Role { get; set; }
        public string Username { get; set; }
    }
}
