import { Component, OnInit } from '@angular/core';
import { PatientService } from 'src/app/service/patient.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-dailog',
  templateUrl: './dailog.component.html',
  styleUrls: ['./dailog.component.css']
})
export class DailogComponent implements OnInit {

  editTestsForm:FormGroup;
  submitted = false;
  id:any;
  planeDetails
  type:string;
  message:string;
  success:boolean;
  failed:boolean;
  constructor( private route: ActivatedRoute,private formBuilder:FormBuilder,private patientservice:PatientService,private router:Router, private datePipe: DatePipe) { }

  ngOnInit() {
    this.editTestsForm = this.formBuilder.group({
      'patientId':new FormControl("",[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
      'doctorId':new FormControl("",[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
      'diag1ActualValue':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
      'diag1NormalRange':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
      'diag2ActualValue': new FormControl("",[Validators.required,Validators.email]),
      'diag2NormalRange':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
      'diag3ActualValue': new FormControl("",[Validators.required]),
      'diag3NormalRange':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
      'serviceDate':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
      'testResultDate':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
      'doctorComments':new FormControl("",[/*Validators.required,Validators.pattern("[0-9]*$"),*/Validators.maxLength(3)])
    })
    this.id = this.route.snapshot.paramMap.get('id');
    console.log(this.id)
    this.planeDetails =this.patientservice.getReportDetails(this.id);
    this.patientservice.getReportDetails(this.id).subscribe(
      data=>{
        console.log(data)
        this.editTestsForm = this.formBuilder.group({
          'patientId':new FormControl(data['patientId'],[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
          'doctorId':new FormControl(data['doctorId'],[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
          'diag1ActualValue':new FormControl(data['diag1ActualValue'],[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
          'diag1NormalRange':new FormControl(data['diag1NormalRange'],[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
          'diag2ActualValue': new FormControl(data['diag2ActualValue'],[Validators.required,Validators.email]),
          'diag2NormalRange':new FormControl(data['diag2NormalRange'],[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
          'diag3ActualValue': new FormControl(data['diag3ActualValue'],[Validators.required]),
          'diag3NormalRange':new FormControl(data['diag3NormalRange'],[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
          'serviceDate':new FormControl(this.datePipe.transform(data['serviceDate'],'yyyy-MM-dd'),[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
          'testResultDate':new FormControl(this.datePipe.transform(data['testResultDate'],'yyyy-MM-dd'),[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
           'doctorComments':new FormControl(data['doctorComments'],[/*Validators.required,Validators.pattern("[0-9]*$"),*/Validators.maxLength(3)])
        })
      })
  }
  get f(){
    return this.editTestsForm.controls;
  }
  const 
  editTests(){

    console.log("Edit Tests Method"); 
    this.patientservice.updateReportdetails(this.id,this.editTestsForm).subscribe(
      data => {
        console.log(data)
        var message=JSON.parse(JSON.stringify(data))['message']; 
      
        if(JSON.parse(JSON.stringify(data))['message']==message)
        {
     
       this.success=true;
       this.router.navigateByUrl("admin");
        }
        
else{
  this.failed=true;
}
      });
  }
  }
