import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/site/User';
import { UserAuthService } from 'src/app/service/user-auth.service';

@Component({
  selector: 'app-profilecomponent',
  templateUrl: './profilecomponent.component.html',
  styleUrls: ['./profilecomponent.component.css']
})
export class ProfilecomponentComponent implements OnInit {

  constructor(private userauthservice:UserAuthService) { }

  ngOnInit() {
  }



  Admindetails()
  {
    return this.userauthservice.loggedInUser  
  }

}
