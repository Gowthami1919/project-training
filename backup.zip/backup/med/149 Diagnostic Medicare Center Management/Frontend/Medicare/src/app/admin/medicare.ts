export interface Medicare{
    id:number;
    name:string;
    description:string;
    amount: number;
    imageUrl:string;
}