﻿using System;
using System.Collections.Generic;

namespace MedicareEF.Models
{
    public partial class Bookappointments
    {
        public int BookappointmentId { get; set; }
        public int PatientId { get; set; }
        public string PatientName { get; set; }
        public string Username { get; set; }
        public int DoctorId { get; set; }
        public string DoctorName { get; set; }
        public string Speciality { get; set; }
        public string SlotBooking { get; set; }
        public string AppointmentStatus { get; set; }
        public string Email { get; set; }
        public int? ServiceId { get; set; }
        public int? Age { get; set; }
        public DateTime? AppoDate { get; set; }
        public int Amount { get; set; }
        public string DoctorApproval { get; set; }

        public Doctor Doctor { get; set; }
        public Patient Patient { get; set; }
        public MediServices Service { get; set; }
    }
}
