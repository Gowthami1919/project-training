import { Component, OnInit } from '@angular/core';
import { DoctorService } from 'src/app/service/doctor.service';
import { PatientService } from 'src/app/service/patient.service';

import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Doctor } from 'src/app/doctor/doctor/doctor';
import { Patient } from 'src/app/patient/patient/patient';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  isDoctor = false;
  isPatient = true;
  doctor: Doctor;
  patient: Patient;
  signupForm: FormGroup;
  error: string;
  cpasswordisnotsame:boolean=false;
  DOB:any;
  today:any;
  ages:any;
  isEmailExist: boolean=false;
  Myage:any
  constructor(private router: Router, private datepipe: DatePipe,private doctorService: DoctorService, private patientService: PatientService) { }

  ngOnInit() {
    {
    

      this.signupForm = new FormGroup({
        'docUsername': new FormControl(null, [Validators.required, Validators.maxLength(10)]),
        'username': new FormControl(null, [Validators.required, Validators.maxLength(10)]),
        'firstName': new FormControl(null, [Validators.required, Validators.pattern('^[A-Za-z]+$'), Validators.maxLength(50)]),
        'lastName': new FormControl(null, [Validators.required, Validators.pattern('^[A-Za-z]+$'), Validators.maxLength(50)]),
        'age': new FormControl(null, [Validators.required, Validators.maxLength(2), Validators.pattern('^[0-9]+$')]),
        'gender': new FormControl(null, [Validators.required]),
        'dateOfBirth': new FormControl(null),
        'contactNumber': new FormControl(null, [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]),
        'altContactNumber': new FormControl(null, [Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]),
        'emailId': new FormControl(null, [Validators.required]),
        'password': new FormControl(null, [Validators.required,Validators.minLength(10),Validators.maxLength(20),Validators.pattern('^[A-Za-z%]+[\\$#\\+{}:\\?\\.,~@\"0-9]+$')]),
        'cpassword': new FormControl(null, [Validators.required,Validators.minLength(10),Validators.maxLength(20)]),
        'addressLine1': new FormControl(null, [Validators.required]),
        'city': new FormControl(this.Myage, [Validators.required, Validators.pattern('^[A-Za-z ]+$')]),
        'state': new FormControl(null, [Validators.required, Validators.pattern('^[A-Za-z ]+$')]),
        'zipCode': new FormControl(null, [Validators.required, Validators.minLength(6), Validators.maxLength(6) ,Validators.minLength(8)]),
        'degree': new FormControl("MBBS", [Validators.required]),
        'speciality': new FormControl(null, [Validators.required]),
        'workHours': new FormControl(null, [Validators.required]),
        'hospitalName': new FormControl(null, [Validators.required])


      });

    }
  }
  getAge(dateOfBirth:Date):number{
    //  var today = Date.now;
    //  var age = today.
    console.log(dateOfBirth);
    console.log("age");
      let today = new Date();
      let todayDate  = this.datepipe.transform(today, 'yyyy')
      var birthdate = new Date(dateOfBirth);
      let birthDay = this.datepipe.transform(birthdate,'yyyy')
      this.Myage = Number(todayDate) - Number(birthDay)
      let m = today.getMonth()-birthdate.getMonth();
      if(m<0 || (m==0 && today.getDate()< birthdate.getDate())){
        this.Myage--;
        }
        console.log(this.Myage);
        this.signupForm.patchValue({age : this.Myage})
        return this.Myage;
  }
  
  get DocUsername() {
     console.log( this.signupForm.get('docUsername')); 
     return this.signupForm.get('docUsername');
  
  }
  get username() {
    return this.signupForm.get('username');
  }
  get firstName() {
    return this.signupForm.get('firstName');
  }
  get lastName() {
    return this.signupForm.get('lastName');
  }
  get age() {
    // return this.signupForm.get('age');
 
  return this.signupForm.get('age')

  }
  get gender() {
    return this.signupForm.get('gender');
  }
  get dateOfBirth() {
    return this.signupForm.get('dateOfBirth');
  }
  get contactNumber() {
    return this.signupForm.get('contactNumber');
  }
  get altContactNumber() {
    return this.signupForm.get('altContactNumber');
  }
  get emailId() {
    return this.signupForm.get('emailId');
  }
  get password() {
    return this.signupForm.get('password');
  }
  get cpassword() {
    return this.signupForm.get('cpassword');
  }
  get addressLine1() {
    return this.signupForm.get('addressLine1');
  }
  get city() {
    return this.signupForm.get('city');
  }
  get state() {
    return this.signupForm.get('state');
  }
  get zipCode() {
    return this.signupForm.get('zipCode');
  }
  get degree() {
    return this.signupForm.get('degree');
  }
  get speciality() {
    return this.signupForm.get('speciality');
  }
  get workHours() {
    return this.signupForm.get('workHours');
  }
  get hospitalName() {
    return this.signupForm.get('hospitalName');
  }
  
 

 OnPatientUserCheck(email:string)
 {
  console.log(email)
  this.patientService.CheckEmail(email).subscribe(
    data => {
      console.log(data)
      if(data['status'] == "No such username")
      {
        this.isEmailExist = false
      }
      else if(data['status'] == "username already exist")
      {
        this.isEmailExist = true
      }

  })
 }
 OnDoctorUserCheck(email:string)
 {
  console.log(email)
  this.doctorService.CheckEmail(email).subscribe(
    data => {
   
      if(data['status'] == "No such username")
      {
        console.log(data['status']);
        this.isEmailExist = false
      }
      else if(data['status'] == "username already exist")
      {
        console.log(data['status']);
        this.isEmailExist = true
      }

  })
 }
  onDoctorClick() {
    this.isDoctor = true;
    this.isPatient = false;
  }
  onPatientClick() {
    this.isDoctor = false;
    this.isPatient = true;
  }
  isEqual() : boolean{
    if (this.signupForm.get('contactNumber').value == this.signupForm.get('altContactNumber').value) {
      return true
    } else {
      return false;
    }
  }
  isPasswordEqual() :boolean
  {
    if (this.signupForm.get('password').value == this.signupForm.get('cpassword').value) {
      return false
    } else {
      return true;
    }
  }
  onSubmit() {
    console.log("In submit")
    console.log(this.signupForm.value);
    if (this.isDoctor) {
      this.doctor = this.signupForm.value;
      console.log(this.doctor);
      this.doctorService.addDoctor(this.signupForm.value).subscribe(
        (response) => {  console.log("Details entered are saved")
          this.error = "ftvtggvftf";
          alert("Successfully logged in, Wait for admin Confirmation")
          this.router.navigate(['/allowlogin']);
      
        },
        (responseError) => {
          this.error = responseError.error.message;
          console.log(this.error);
     
          this.router.navigate(['/allowlogin']);
        });
    }
    if (this.isPatient) {
      this.patient = this.signupForm.value;
      console.log(this.patient);
      this.patientService.addPatient(this.signupForm.value).subscribe(
        (response) => {
          this.error = '';
          alert("Successfully logged in, Wait for admin Confirmation")
          this.router.navigate(['/allowlogin']);
       
        },
        (responseError) => {
          this.error = responseError.error.message;
          console.log(this.error);
         
          this.router.navigate(['/allowlogin']);
        });
    }
  }

}
