export interface admindetails
{
    AdId:number;
    AdFirstName:string;
    AdLastName:string;
    Role:String;
    AdContactNumber:number;

}