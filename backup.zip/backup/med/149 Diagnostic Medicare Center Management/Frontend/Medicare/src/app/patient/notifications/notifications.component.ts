import { Component, OnInit } from '@angular/core';
import { DoctorService } from 'src/app/service/doctor.service';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { PatientService } from 'src/app/service/patient.service';
import { Observable } from 'rxjs';
import { ExcelService } from 'src/app/excel.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
userdetails:any;
  apponotificationlist:Observable<any[]>;
  testreportnotificationList:Observable<any[]>;
  appoYesnotify:any;
  appoNonotify:any;
  testnotify:any;
  not:any
  showAppointmentapprove:boolean;
  showTestReportsapproved:boolean;
  showTestReportsNotapproved:boolean;
  Shownewnotifications:boolean;
  isActive: boolean
  appnotifylist
  noreports:boolean=false;
  constructor(private doctorService: DoctorService,private userauthservice:UserAuthService, private userAuthService: UserAuthService, private patientService: PatientService,private excelService:ExcelService) { }

  ngOnInit() {
    this.isActive = true
    this.userdetails=this.userauthservice.loggedInUser;
    this.patientService.checkappointmentstatus(this.userdetails[0].patientId).subscribe(
      data => {
        console.log(data)

      
        if(JSON.parse(JSON.stringify(data))['message']=="Approved")
        {
        
         this.showAppointmentapprove=true; 
         
         this.apponotificationlist=this.patientService.checkappointmentstatus(this.userdetails[0].patientId);
         console.log(this.apponotificationlist);
         this.appoYesnotify =this.userAuthService.appoNotifyList = data['approved'];
         console.log(this.appoYesnotify);

         this.appoNonotify=this.userAuthService.appoNotifyList = data['rejected'];
         console.log(this.appoNonotify);
         console.log( this.appnotifylist);
        }
        else{
           this.Shownewnotifications=true;
           this.showAppointmentapprove=false;
           this.showTestReportsNotapproved =true;
           this.showTestReportsapproved=false;
         
        }
       
       } ) ;
       this.patientService.checkTestReportStatus(this.userdetails[0].patientId).subscribe(
        data => {
          console.log(data)
         
        console.log(this.userdetails[0].patientId+"dkjfhjdshgjd");
          if(JSON.parse(JSON.stringify(data))['message']=="testResult")
          {
          
           this.showTestReportsapproved=true; 
           this.testnotify=this.userAuthService.appoNotifyList = data['approved'];
           console.log(this.testnotify);
           this.testreportnotificationList=this.patientService.checkappointmentstatus(this.userdetails[0].patientId);
           console.log(this.testreportnotificationList);
        
          }
          else if(JSON.parse(JSON.stringify(data))['message']=="empty")
          {
            console.log("came into empty message method empty");
            console.log(this.patientService.RaiseTestRequest(this.userdetails[0].patientId));
            this.noreports=true;
          }
         } ) 

         
    

}
exportAsXLSX():void {
  this.excelService.exportAsExcelFile(this.testnotify, 'sample');
}
raisedRequest()
{
  console.log(this.userdetails.patientId);

  if( this.patientService.RaiseTestRequest(this.userdetails[0].patientId)== null)
  {
   console.log(this.patientService.RaiseTestRequest(this.userdetails[0].patientId));
   this.noreports=true;
  }
  else{
    this.showTestReportsNotapproved=true;
    this.patientService.RaiseTestRequest(this.userdetails[0].patientId);
  }
  
 
 
}
close()
{
  this.isActive = false
}

}