﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace MedicareEF.Models
{
    public partial class MedicareContext : DbContext
    {
        public MedicareContext()
        {
        }

        public MedicareContext(DbContextOptions<MedicareContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Doctor> Doctor { get; set; }
        public virtual DbSet<MediServices> MediServices { get; set; }
        public virtual DbSet<Patient> Patient { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("server=PCIN480238;database=Medicare; trusted_connection=yes");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.3-servicing-35854");

            modelBuilder.Entity<Doctor>(entity =>
            {
                entity.HasKey(e => e.DtId)
                    .HasName("Dt_Doctor");

                entity.Property(e => e.DtId).HasColumnName("Dt_Id");

                entity.Property(e => e.DtAddressLine1)
                    .IsRequired()
                    .HasColumnName("Dt_AddressLine_1")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DtAddressLine2)
                    .HasColumnName("Dt_AddressLine_2")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DtAge).HasColumnName("Dt_Age");

                entity.Property(e => e.DtAltNumber).HasColumnName("Dt_AltNumber");

                entity.Property(e => e.DtCity)
                    .IsRequired()
                    .HasColumnName("Dt_City")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DtContactNumber).HasColumnName("Dt_ContactNumber");

                entity.Property(e => e.DtDegree)
                    .HasColumnName("Dt_degree")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DtDob)
                    .HasColumnName("Dt_Dob")
                    .HasColumnType("date");

                entity.Property(e => e.DtEmailId)
                    .IsRequired()
                    .HasColumnName("Dt_EmailId")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DtFirstName)
                    .IsRequired()
                    .HasColumnName("Dt_First_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DtGender)
                    .IsRequired()
                    .HasColumnName("Dt_Gender")
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.DtHospitalName)
                    .HasColumnName("Dt_HospitalName")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DtLastName)
                    .IsRequired()
                    .HasColumnName("Dt_Last_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DtMdId).HasColumnName("Dt_Md_Id");

                entity.Property(e => e.DtPassword)
                    .IsRequired()
                    .HasColumnName("Dt_Password")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.DtSpeciality)
                    .HasColumnName("Dt_Speciality")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DtState)
                    .IsRequired()
                    .HasColumnName("Dt_State")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DtWorkHours)
                    .HasColumnName("Dt_WorkHours")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.DtZipcode).HasColumnName("Dt_Zipcode");

                entity.HasOne(d => d.DtMd)
                    .WithMany(p => p.Doctor)
                    .HasForeignKey(d => d.DtMdId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("dt_ms_fk");
            });

            modelBuilder.Entity<MediServices>(entity =>
            {
                entity.HasKey(e => e.MdId)
                    .HasName("Medi_Constraint");

                entity.ToTable("Medi_Services");

                entity.Property(e => e.MdId).HasColumnName("Md_Id");

                entity.Property(e => e.MdAmount).HasColumnName("Md_Amount");

                entity.Property(e => e.MdDescription)
                    .HasColumnName("Md_Description")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.MdService)
                    .IsRequired()
                    .HasColumnName("Md_Service")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Patient>(entity =>
            {
                entity.HasKey(e => e.PtId)
                    .HasName("Pt_patient");

                entity.Property(e => e.PtId).HasColumnName("Pt_Id");

                entity.Property(e => e.PtAddress1)
                    .IsRequired()
                    .HasColumnName("Pt_Address1")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PtAddress2)
                    .HasColumnName("Pt_Address2")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PtAge).HasColumnName("Pt_Age");

                entity.Property(e => e.PtAltNumber).HasColumnName("Pt_AltNumber");

                entity.Property(e => e.PtCity)
                    .IsRequired()
                    .HasColumnName("Pt_City")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PtContactNumber).HasColumnName("Pt_ContactNumber");

                entity.Property(e => e.PtDob)
                    .HasColumnName("Pt_Dob")
                    .HasColumnType("date");

                entity.Property(e => e.PtEmail)
                    .IsRequired()
                    .HasColumnName("Pt_Email")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PtFirstName)
                    .IsRequired()
                    .HasColumnName("Pt_FirstName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PtGender)
                    .IsRequired()
                    .HasColumnName("Pt_Gender")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.PtLastName)
                    .IsRequired()
                    .HasColumnName("Pt_LastName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PtPassword)
                    .IsRequired()
                    .HasColumnName("Pt_Password")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.PtState)
                    .IsRequired()
                    .HasColumnName("Pt_State")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PtZipCode)
                    .IsRequired()
                    .HasColumnName("Pt_ZipCode")
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });
        }
    }
}
