import { Component, OnInit } from '@angular/core';
import { DoctorService } from 'src/app/service/doctor.service';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { PatientService } from 'src/app/service/patient.service';
import { Router } from '@angular/router';
import { FormGroup,FormBuilder, Validators, FormControl } from '@angular/forms';
import { Testreports } from '../doctor/Testreports';

@Component({
  selector: 'app-uploadtests',
  templateUrl: './uploadtests.component.html',
  styleUrls: ['./uploadtests.component.css']
})
export class UploadtestsComponent implements OnInit {

  editTestsForm:FormGroup;
  doctorName:string;
  loogedinvalues: any;
  AllpatientReports: any[];
  Uploadtest:boolean=false;
  islist:boolean=true;
singlepatientreports:any;
  constructor(private doctorService: DoctorService, private FormBuilder:FormBuilder, private userAuthService: UserAuthService, private router: Router,private patientService:PatientService ) { }

  ngOnInit()
   {
    this.islist=true;
        this.doctorService.getPatientReports(this.userAuthService.loggedInUser[0].doctorId).subscribe(data=>{
       if(data==null)
       {
         console.log("data is null");
       }
       else{
           console.log(data+"dgfgfghghg")
          this.AllpatientReports=data;
          console.log(this.AllpatientReports);
       }
        
    
    });
        this.loogedinvalues=this.userAuthService.loggedInUser;
        console.log(this.loogedinvalues[0].username);
        this.editTestsForm = this.FormBuilder.group({
      'patientId':new FormControl("",[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
      'patientname':new FormControl("",[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
      'MedicareServiceId':new FormControl("",[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
      'doctorId':new FormControl(this.loogedinvalues[0].username,[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
      'diag1ActualValue':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
      'diag1NormalRange':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
      'diag2ActualValue': new FormControl("",[Validators.required,Validators.email]),
      'diag2NormalRange':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
      'diag3ActualValue': new FormControl("",[Validators.required]),
      'diag3NormalRange':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
      'serviceDate':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
      'testResultDate':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
      'doctorComments':new FormControl("",[/*Validators.required,Validators.pattern("[0-9]*$"),*/Validators.maxLength(3)]),

    })

  }
  






upload(s:Testreports)
{
  this.Uploadtest=true;
this.islist=false;
  console.log("hai"+s);
    this.editTestsForm = this.FormBuilder.group({
        'patientId':new FormControl(s.patientId,[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
        'doctorId':new FormControl(this.userAuthService.loggedInUser[0].doctorId,[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
        'ServiceId':new FormControl(s.serviceId,[Validators.required,Validators.pattern("[a-zA-Z]*$")]),
        'diag1ActualValue':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
        'diag1NormalRange':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
        'diag2ActualValue': new FormControl("",[Validators.required,Validators.email]),
        'diag2NormalRange':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
        'diag3ActualValue': new FormControl("",[Validators.required]),
        'diag3NormalRange':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
        'serviceDate':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
        'testResultDate':new FormControl("",[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(10),Validators.minLength(10)]),
        'doctorComments':new FormControl("",[/*Validators.required,Validators.pattern("[0-9]*$"),*/Validators.maxLength(3)])
  
      })
}

editTests()
{
 
  this.doctorService.UploadPatientTestReports(this.editTestsForm).subscribe(
    data => {
      console.log(data)
      var message=JSON.parse(JSON.stringify(data))['message']; 
    
      if(JSON.parse(JSON.stringify(data))['message']==message)
      {
      this.router.navigateByUrl("doctor");
      
      }


    });
}

}
