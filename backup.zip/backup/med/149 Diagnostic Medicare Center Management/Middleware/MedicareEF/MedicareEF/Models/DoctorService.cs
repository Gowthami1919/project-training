﻿using System;
using System.Collections.Generic;

namespace MedicareEF.Models
{
    public partial class DoctorService
    {
        public int DocServiceId { get; set; }
        public int? DocId { get; set; }
        public int? ServiceId { get; set; }

        public Doctor Doc { get; set; }
        public MediServices Service { get; set; }
    }
}
