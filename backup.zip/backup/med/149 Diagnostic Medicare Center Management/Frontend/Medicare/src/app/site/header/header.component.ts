import { Component, OnInit } from '@angular/core';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { DoctorService } from 'src/app/service/doctor.service';
import { PatientService } from 'src/app/service/patient.service';
import { AdminComponent } from 'src/app/admin/admin/admin.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  role: string;
  patientLength: number;
  doctorLength: number;
  Rolename:String;
  
  constructor(private userAuthService: UserAuthService, private doctorService: DoctorService, private patientService: PatientService,private r:Router) { }

  ngOnInit() {
   
    
  }
  
  admin(){
  

    return this.userAuthService.getRole();

  }
  isAuthenticated() {
    return this.userAuthService.loggedIn;
  }
  getRole() {
    return this.userAuthService.getRole();
    
  }

  getUser() {
    return this.userAuthService.getRole();
  
  }
  
  patientRequest(){
    this.doctorService.doctorApproval=false;
    this.patientService.patientApproval=true;

  }
  doctorRequest(){
    this.doctorService.doctorApproval=true;
    this.patientService.patientApproval=false;

  }
  
  onSignOut() {
    this.userAuthService.logout();
  }

  method()
  {
    console.log(this.userAuthService.getRole());
;    if(this.userAuthService.getRole()=='Admin')
    {
      console.log(this.userAuthService.getRole());
      
      this.r.navigateByUrl("admin");
    }
    else if( this.userAuthService.getRole()=='Patient')
    {
      console.log(this.userAuthService.getRole());
      this.r.navigateByUrl("patient");
    }
    else
    {
      console.log(this.userAuthService.getRole());
      this.r.navigateByUrl("doctor");
    }
  }
  notification()
  {
    console.log(this.userAuthService.getRole());
    ;    if(this.userAuthService.getRole()=='Admin')
        {
          console.log(this.userAuthService.getRole());
          
          this.r.navigateByUrl("admin");
        }
        else if( this.userAuthService.getRole()=='Patient')
        {
          console.log(this.userAuthService.getRole());
          this.r.navigateByUrl("notify");
        }
        else
        {
          console.log(this.userAuthService.getRole());
          this.r.navigateByUrl("doctor");
        }
  }
}
