export interface BookAppointment {
   
     do_id :number,
     do_first_name:String,
     do_doctor_id:String,
     do_last_name:String,
     do_age:number,
     do_gender:String,
     do_date_of_birth:Date,
     do_contact_number:number,
     do_alt_contact_number:number,
     do_email_id:String,
     do_password:String,
     do_address_line1:String,
     do_address_line2:String,
     do_city:String,
     do_state:String,
     do_zip_code:number,
     do_degree:String,
     do_speciality:String,
     do_work_hours:String,
     do_hospital_name:String,
     do_admin_approved:boolean,
     do_admin_reject:boolean;

}