import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllowLoginComponent } from './allow-login.component';

describe('AllowLoginComponent', () => {
  let component: AllowLoginComponent;
  let fixture: ComponentFixture<AllowLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllowLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllowLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
