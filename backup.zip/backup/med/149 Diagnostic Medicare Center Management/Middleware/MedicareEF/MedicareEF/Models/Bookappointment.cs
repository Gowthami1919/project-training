﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MedicareEF.Models
{
    public class Bookappointment
    {
        public int BookappointmentId { get; set; }
        public int PatientId { get; set; }
        public string PatientName { get; set; }
        public string Username { get; set; }
        public int DoctorId { get; set; }
        public string DoctorName { get; set; }
        public string Speciality { get; set; }
        public string SlotBooking { get; set; }
        public string AppointmentStatus { get; set; }
        public string Email { get; set; }
        public int? ServiceId { get; set; }
        public int? Age { get; set; }
        public int Amount { get; set; }
        public DateTime AppoDate { get; set; }
        public string DoctorApproval { get; set; }
    }
}
