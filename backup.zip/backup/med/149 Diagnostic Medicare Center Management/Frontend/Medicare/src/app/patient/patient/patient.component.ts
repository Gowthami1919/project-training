import { Component, OnInit } from '@angular/core';
import { Medicare } from 'src/app/admin/medicare';
import { DoctorService } from 'src/app/service/doctor.service';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { Doctor } from 'src/app/doctor/doctor/doctor';
import { BookAppointment } from './book-appoitment';
import { PatientService } from 'src/app/service/patient.service';
import { Observable } from 'rxjs';
import { AuthGuard } from 'src/app/service/auth.guard';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit {
  images = ['https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
  'https://images.unsplash.com/photo-1526256262350-7da7584cf5eb?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
  'https://images.unsplash.com/photo-1435527173128-983b87201f4d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1347&q=80',
  'https://images.unsplash.com/photo-1578308175085-444a1fbea0fe?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1368&q=80',
  'https://images.unsplash.com/photo-1532094349884-543bc11b234d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80'
  
  ];

  medicareService: Medicare[];
  doctors: Doctor[];
  doctor: boolean;
  status:any;
  medicare = false;
  appointment = false;
  myReport:boolean=false;
  appointments: BookAppointment[];
  book: boolean;
  alldata:BookAppointment[];
  h:History[];
  view:boolean=false;
  aa:History;
  IsServiceViewed:boolean=false;
  ServicesList:Observable<any[]>;
  AvailDoctors:Observable<any[]>;
  singleservicedetails:any;
  IssingleServiceViewed: boolean;
  IsDoctorAvail:boolean;
  ListOfDoctorsViewed:boolean;
  availstatus:boolean
  doctorservicedetails:Observable<any[]>;
  availStatus: boolean;
  constructor(private doctorService: DoctorService,private userauthservice:UserAuthService, private userAuthService: UserAuthService, private patientService: PatientService,private router:Router) { }

  ngOnInit() {
    const patientId = this.userAuthService.getRole();
    this.ServicesList=this.patientService.getservicesavailble();
    this.IssingleServiceViewed=false;
    this.IsDoctorAvail=false;
    this.ListOfDoctorsViewed=false;
    console.log(this.userauthservice.loggedInUser  );
  }

  showMedicares() {
    this.book=false; 
    this.doctor = false
    this.appointment = false;
    this.medicare = true;
    this.myReport=false;
  }
  showNotification()
{
  this.router.navigateByUrl("notify");
}
  showDoctors() {
    this.doctor = true
    this.medicare = false;
    this.appointment = false;
    this.book=false; 
    this.myReport=false;
  }
  bookAppointment(){
    this.doctor = false
    this.medicare = false;
    this.appointment = false;
    this.book=true; 
    this.myReport=false;
  }
  showAppointment() {
    this.doctor = false
    this.medicare = false;
    this.IsServiceViewed=true;
    this.book=false;
    this.myReport=false;

  }
  Admindetails()
{
  return this.userauthservice.loggedInUser  
}
  ViewallServices(id:number)
{
  this.IssingleServiceViewed=true;
  this.IsServiceViewed=false;
  this.IsDoctorAvail=false;
  this.ListOfDoctorsViewed=false;

  console.log(id);
  // this.isViewed=true;
    this.patientService.getALLservicesavailble(id).subscribe(data=>{
      //this.AllpatientDetails=data;
      console.log(data)
      this.singleservicedetails=data;
      
    });
  setTimeout(() => {
    this.IssingleServiceViewed=true;
  }, 1000);
}
DoctorsAvailable(serviceID:number)
{
  this.IsDoctorAvail=true;
  this.IssingleServiceViewed=false;
  this.IsServiceViewed=false;

  this.ListOfDoctorsViewed=false;
  console.log(serviceID);
  this.patientService.GetAllDoctorsAvailble(serviceID).subscribe
  (data =>
    {
      this.AvailDoctors=data
      if(this.AvailDoctors[0].availStatus=="Available")
      {
        console.log(this.AvailDoctors[0].availStatus)
       this.availstatus=true
       this.availStatus=false
      }
      else{
      this.availstatus=false
      this.availStatus=true
      }
    });

 
 
}
AvailableDoctorDetails(doctorid:number)
{
  this.ListOfDoctorsViewed=true;
  this.IsServiceViewed=false;
  this.IssingleServiceViewed=false;
  this.IsDoctorAvail=false;
 
  console.log(doctorid);
  this.doctorservicedetails= this.patientService.GetServicedetailsofDoctorAvail(doctorid);
  setTimeout(() => {
    this.ListOfDoctorsViewed=true;
  }, 1000);
}

  }
