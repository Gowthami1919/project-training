import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './site/login/login.component';
import { AllowLoginComponent } from './allow-login/allow-login.component';
import { SignupComponent } from './site/signup/signup.component';
import { AdminComponent } from './admin/admin/admin.component';
import { PatientComponent } from './patient/patient/patient.component';
import { AuthGuard } from './service/auth.guard';
import { DoctorComponent } from './doctor/doctor/doctor.component';
import { ContactusComponent } from './contactus/contactus.component';
import { DailogComponent } from './admin/dailog/dailog.component';
import { BookappointmentComponent } from './patient/bookappointment/bookappointment.component';
import { NotificationsComponent } from './patient/notifications/notifications.component';
import { ProfilecomponentComponent } from './patient/profilecomponent/profilecomponent.component';
import { AddserviceComponent } from './doctor/addservice/addservice.component';
import { MyservicesComponent } from './doctor/myservices/myservices.component';
import { UploadtestsComponent } from './doctor/uploadtests/uploadtests.component';
import { AppointmentsrequestsComponent } from './doctor/appointmentsrequests/appointmentsrequests.component';




const routes: Routes = [
  { path: 'login', component: LoginComponent , canActivate: [AuthGuard] },
  { path: 'loginAs/:id', component: LoginComponent  },
  { path: 'appo/:id/:docid', component: BookappointmentComponent , canActivate: [AuthGuard] },
{ path: 'allowlogin', component: AllowLoginComponent  },
{ path: 'editreport/:id', component: DailogComponent  ,canActivate: [AuthGuard]},
  { path: 'signup', component: SignupComponent },
  { path: 'addservice', component: AddserviceComponent ,canActivate: [AuthGuard]},
  { path: 'myservice', component: MyservicesComponent ,canActivate: [AuthGuard]},
  { path: 'upload', component: UploadtestsComponent,canActivate: [AuthGuard] },
  { path: 'requests', component: AppointmentsrequestsComponent,canActivate: [AuthGuard] },
  { path: 'prof', component: ProfilecomponentComponent ,canActivate: [AuthGuard]},
  { path: 'notify', component: NotificationsComponent,canActivate: [AuthGuard] },
{ path: 'admin', component: AdminComponent, canActivate: [AuthGuard]
}, { path: 'patient', component: PatientComponent,canActivate: [AuthGuard]},
  { path: 'doctor', component: DoctorComponent, canActivate: [AuthGuard] },
{ path: 'contact', component: ContactusComponent },
  {path: '', redirectTo: 'allowlogin', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
