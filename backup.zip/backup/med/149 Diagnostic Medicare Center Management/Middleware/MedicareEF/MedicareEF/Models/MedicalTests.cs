﻿using System;
using System.Collections.Generic;

namespace MedicareEF.Models
{
    public partial class MedicalTests
    {
        public int ReportId { get; set; }
        public int PatientId { get; set; }
        public int DoctorId { get; set; }
        public int ServiceId { get; set; }
        public DateTime ServiceDate { get; set; }
        public DateTime? TestResultDate { get; set; }
        public string Diag1ActualValue { get; set; }
        public string Diag1NormalRange { get; set; }
        public string Diag2ActualValue { get; set; }
        public string Diag2NormalRange { get; set; }
        public string DoctorComments { get; set; }
        public string Diag3NormalRange { get; set; }
        public string Diag3ActualValue { get; set; }
        public string AdminApproval { get; set; }
        public string DoctorViewed { get; set; }
        public string PtRequestRaised { get; set; }

        public Doctor Doctor { get; set; }
        public Patient Patient { get; set; }
        public MediServices Service { get; set; }
    }
}
