export class patientdetails{
   patientId:number;
    firstName:string;
 role:String;
 Ptadcomments:string;
}