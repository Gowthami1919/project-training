import { Component, OnInit } from '@angular/core';
import { DoctorService } from 'src/app/service/doctor.service';
import { User } from 'src/app/site/User';
import { UserAuthService } from 'src/app/service/user-auth.service';

@Component({
  selector: 'app-addservice',
  templateUrl: './addservice.component.html',
  styleUrls: ['./addservice.component.css']
})
export class AddserviceComponent implements OnInit {
  MyServices: any[];
  AllServices: any;
  notalreadyexists:boolean=false;
  alreadyexists:boolean=false;
  constructor(private doctorService:DoctorService,private userAuthService:UserAuthService ) { }

  ngOnInit() {
    this.doctorService.getAllMedServices().subscribe(data=>{
      this.AllServices=data;
          console.log(this.AllServices);
      });
      if(this.AllServices!=null){
             console.log("jkhjhghjg");
      }
      else{
               console.log("Hello");
      }
           console.log(this.AllServices);

      
        console.log("patientrequesyt");
  }
  AddServiceToDoctor(service_id:number)
  {
    var id=this.userAuthService.loggedInUser[0].doctorId;
    console.log(id+"uydhfujdhgfjiads");
    this.doctorService.AddServiceToDoctor(service_id,this.userAuthService.loggedInUser[0].doctorId).subscribe(data=>{
      console.log(data)
      var msg=(JSON.parse(JSON.stringify(data))['message'])
      if(msg=="Already Added")
      {
          this.alreadyexists=true;
      }
      else{
      this.notalreadyexists=true;
      }
  
  });
  }
}
