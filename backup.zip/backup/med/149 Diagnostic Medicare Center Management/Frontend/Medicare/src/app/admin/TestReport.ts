export interface TestReport {
    reportId:number;
    patientId:String;
    doctorid:String;
    medicareservicesid:number;
    serviceDate:Date;
    diag1ActualValue:number;
    diag1NormalRange:number;
    diag2NormalRange:number;
    diag2ActualValue:number;
    diag3NormalRange:number;
    diag3ActualValue:number;
  testResultDate:Date;
    doctorComments:String;
    admin_approval:boolean
}