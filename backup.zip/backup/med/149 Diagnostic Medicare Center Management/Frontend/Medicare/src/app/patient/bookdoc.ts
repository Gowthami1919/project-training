export interface Bookdoc{
    ba_id:number;
    ba_patient_id:String;
    ba_doctor_id:String;
    ba_medicare_service_id:String;
    ba_date:Date;
    ba_approved:boolean;
    ba_reject:boolean;
} 