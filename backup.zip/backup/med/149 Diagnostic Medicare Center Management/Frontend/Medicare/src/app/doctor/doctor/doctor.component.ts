import { Component, OnInit } from '@angular/core';
import { DoctorService } from 'src/app/service/doctor.service';
import { Doctor } from './doctor';
import { Medicare } from '../../admin/medicare';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { Router } from '@angular/router';
import { BookAppointment } from 'src/app/patient/patient/book-appoitment';
import { Patient } from 'src/app/patient/patient/patient';
import { PatientService } from 'src/app/service/patient.service';
import { Bookdoc } from 'src/app/patient/bookdoc';
import { FormGroup, FormBuilder,FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']
})
export class DoctorComponent implements OnInit {
 
  images = ['https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
  'https://images.unsplash.com/photo-1495653797063-114787b77b23?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
  'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1352&q=80',
  'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
  ];


  showappointments:boolean=false;
  isPatient:boolean=false;
  appointments: Bookdoc[];
  showservice:boolean=false;
  AllService:Observable<any[]>;
  isAdded:boolean=false;
  uploadDetails:boolean=false;
  cust_i:String;
  med_id:String;
  d:Date;
  afterSubmit:boolean=false;
  serveView:boolean=false;
  isAddservice:boolean=false;
  isUpdateService:boolean=false;
  AllServices:any[];
  AllpatientRequest:any[];
  AllpatientReports:any[];
  editTestsForm:FormGroup;
  message : boolean=false;
  MyServices:any[];
  myservices:Observable<any[]>
  ShowMyservices:boolean=false;

loogedinvalues:any
  po:Bookdoc={
    ba_patient_id:"",
    ba_doctor_id:"",
    ba_medicare_service_id:"",
    ba_date:new Date(),
    ba_approved:true,
    ba_reject:false,
    ba_id:0

  };
  p:Bookdoc;
  uploadForm: FormGroup;
  doctorName:string;
  constructor(private doctorService: DoctorService, private FormBuilder:FormBuilder, private userAuthService: UserAuthService, private router: Router,private patientService:PatientService ) { }
  patients: Bookdoc[];
  ngOnInit() {
    this.loogedinvalues=this.userAuthService.loggedInUser;
    console.log( this.loogedinvalues);
    console.log(this.loogedinvalues)
    console.log(this.userAuthService.loggedInUser[0].doctorId);

                  this.doctorService.getAllMedServices().subscribe(data=>{
                  this.AllServices=data;
                      console.log(this.AllServices);
                  });
                  if(this.AllServices!=null){
                         console.log("jkhjhghjg");
                  }
                  else{
                           console.log("Hello");
                  }
                       console.log(this.AllServices);

                  
                    console.log("patientrequesyt");
    this.doctorService.PatientRequest(this.userAuthService.loggedInUser[0].doctorId).subscribe(data=>{
      this.AllpatientRequest=data;
     console.log(this.AllpatientRequest);
      this.doctorService.getPatientReports(this.userAuthService.loggedInUser[0].doctorId).subscribe(data=>{
        this.AllpatientReports=data;
        console.log(this.AllpatientReports);
        this.doctorService.getAlldoctorServices(this.userAuthService.loggedInUser[0].doctorId).subscribe(data=>{
          this.MyServices=data;
          console.log(this.MyServices);
        })
      })
     
    });
   
  
  }

  Click()
{
  this.message=!this.message;
}

Admindetails()
{
  return this.userAuthService.loggedInUser  
}

  showAppointments()
  {
      this.showappointments=true;
      this.isPatient=false;
      this.showservice=false;
      this.uploadDetails=false;
      this.afterSubmit=false;
      this.serveView = false;
      this.isAddservice=true;
      this.isUpdateService=true;
  }

  showPendings()
  {
      this.isPatient=true;
      this.showappointments=false;
      this.showservice=false;
      this.uploadDetails=false;
      this.serveView = false;
      this.isAddservice=true;
      this.isUpdateService=true;
      this.ShowMyservices=false;
  }
  showServices()
  {
    this.showservice=true;
    this.afterSubmit=false;
    this.isPatient=false;
    this.showappointments=false;
    this.uploadDetails=false;
    this.serveView = true;
    this.ShowMyservices=false;
    

  }
  AddService(){
    this.isAddservice=true;
    this.showservice=false;
    this.afterSubmit=false;
    this.isPatient=false;
    this.showappointments=false;
    this.ShowMyservices=false;
  }

  UpdateService(){
    this.showservice=false;
    this.afterSubmit=false;
    this.isPatient=false;
    this.showappointments=false;
    this.isUpdateService=true;
    this.ShowMyservices=false;
  }
  showMyServices(){
    this.showservice=false;
    this.afterSubmit=false;
    this.isPatient=false;
    this.showappointments=false;
    this.isUpdateService=false;
    this.ShowMyservices=true;
  }
  
  





}