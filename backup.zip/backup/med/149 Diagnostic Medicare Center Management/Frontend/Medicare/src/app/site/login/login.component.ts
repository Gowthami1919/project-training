import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';

import { UserAuthService } from 'src/app/service/user-auth.service';
import { AuthenticationService } from 'src/app/service/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    l
    message:any;
  PatientReject:void;
  DoctorReject:void;
  isLoginValid = true;
  error: string;
  id = this.route.snapshot.paramMap.get('id');
  loginForm: FormGroup;
  isDoctor = false;
  isPatient = true;
  isAdmin = false;
  isLoginTrue:boolean=false;
  Role:string;
adminId:number;
commentstrue:boolean=false;
commentsfalse:boolean=false;
  constructor(private route: ActivatedRoute,private fb: FormBuilder, private router: Router, private authenticationService: AuthenticationService, private userAuthService: UserAuthService) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      username: [''],
      password: [''

      ]
    });
  }
  passwordToggle()
  {
    if(this.passwordshow)
    {
      this.passwordshow=false;
      this.passwordType="Password";
    }
    else
    {
      this.passwordshow=true;
      this.passwordType="Text";
    }
  }


passwordshow:boolean=false;
  passwordType:string="Password";



  get username() {
    return this.loginForm.get('username');
  }
  get password() {
    return this.loginForm.get('password');
  }
  onDoctorClick() {
    this.isDoctor = true;
    this.isPatient = false;
    this.isAdmin = false;
    

  }
  onPatientClick() {
    this.isDoctor = false;
    this.isPatient = true;
    this.isAdmin = false;
  }
  onAdminClick() {
    this.isDoctor = false;
    this.isPatient = false;
    this.isAdmin = true;

  }
  
  onLogin() {
    const username = this.loginForm.value.username;
    const password = this.loginForm.value.password;
    console.log(username);
    console.log(password);

    if ( this.id == 'Admin') {

      console.log('Admin authentication is processing');
        this.authenticationService.Adminauthenticate(username,password).subscribe((data) => {
            console.log('success');
            console.log(data)
          this.message=  console.log(JSON.parse(JSON.stringify(data))['message'])
            this.userAuthService.setRole(this.id);
            console.log(this.adminId);
            //  this.userAuthService.setUser(data.user);
            if(JSON.parse(JSON.stringify(data))['message']=="Logined succefully")
            {
               this.isLoginTrue=true;
               this.userAuthService.setLoggedIn(true);
              
               console.log(data)
               this.userAuthService.loggedInUser = data['user'];
               console.log(this.userAuthService.loggedInUser)
              this.router.navigateByUrl("admin");
              this.isLoginTrue=true;
              
            }
            else {
              this.message=  console.log(JSON.parse(JSON.stringify(data))['message'])
              this.isLoginValid=false;
              this.userAuthService.setLoggedIn(false);
              alert("Invalid User");
              this.loginForm = this.fb.group({
                username: [''],
                password: [''
          
                ]
              });
      
              
            }
            
        },
        (error) => {
               console.log("error");
          this.isLoginValid = false;
        if (error.status == 401)
                this.error = "Invalid Username/Password";
            }
          );
         
        }

       else if ( this.id == 'Doctor') {

          console.log('Admin authentication is processing');
          
            this.authenticationService.Doctorauthenticate(username,password).subscribe((data) => {
                console.log('success');
                console.log(data)
                console.log(JSON.parse(JSON.stringify(data))['message'])
                this.userAuthService.setRole(this.id);
               
                //  this.userAuthService.setUser(data.user);
                if(JSON.parse(JSON.stringify(data))['message']=="Logined succefully")
                {
                  this.userAuthService.loggedInUser = data['user'];
                   this.userAuthService.setLoggedIn(true);
                  this.router.navigateByUrl("doctor");
                  this.isLoginTrue=true;
                }
                else{
                  
               
                  this.isLoginTrue=false;
                  this.PatientReject=this.userAuthService.rejectedUser = data['reject'];
                  console.log(this.PatientReject);
                   this.message=this.PatientReject['docAdComments']
                  console.log(this.message);
                if( data['reject'] != null)
                {this.commentstrue=true
                }
                else 
                {
                this.commentsfalse=true;
                }
                this.isLoginValid=false;
                  this.userAuthService.setLoggedIn(false);
                  
                 
              
                  this.loginForm = this.fb.group({
                    username: [''],
                    password: [''
              
                    ]
                  });
                }
                
            },
            (error) => {
                   console.log("error");
              this.isLoginValid = false;
            if (error.status == 401)
                    this.error = "Invalid Username/Password";
                }
              );
              }

              else if ( this.id == 'Patient') {

                console.log('Admin authentication is processing');
                
                  this.authenticationService.Patientauthenticate(username,password).subscribe((data) => {
                      console.log('success');
                      console.log(data)
                      console.log(JSON.parse(JSON.stringify(data))['message'])
                      this.userAuthService.setRole(this.id);
                
                      //  this.userAuthService.setUser(data.user);
                      if(JSON.parse(JSON.stringify(data))['message']=="Logined succefully")
                      {
                        console.log(data['user']);
                        this.isLoginTrue=true;
                        this.userAuthService.loggedInUser = data['user'];
                        console.log("Authorised User");
                         this.userAuthService.setLoggedIn(true);
                        this.router.navigateByUrl("patient");
                      }
                      else {
                        this.isLoginTrue=false;
                        
                      this.PatientReject= this.userAuthService.rejectedUser = data['reject'];
               
                        this.userAuthService.setLoggedIn(false);
                        this.message=this.PatientReject['ptAdComments']
                         if( data['reject'] != null)
                       {this.commentstrue=true
                       }
                      else 
                      {
                      this.commentsfalse=true;
                      }
                      this.isLoginValid=false;
                        this.userAuthService.setLoggedIn(false);
                        
                       
                    
                        this.loginForm = this.fb.group({
                          username: [''],
                          password: [''
                    
                          ]
                        });
                      }
                      
                  },
                  (error) => {
                         console.log("error");
                    this.isLoginValid = false;
                  if (error.status == 401)
                          this.error = "Invalid Username/Password";
                      }
                    );
                    }
                  }}

              























    // this.authenticationService.authenticate(username, password).subscribe((data) => {
    //   console.log('success');
    //   console.log(data)
    //   this.userAuthService.setToken(data.token);
    //   this.userAuthService.setRole(data.role);
    //   this.userAuthService.setUser(data.user);
    //   this.router.navigate(['/login']);
    //   const role = this.userAuthService.getRole();
    //   console.log(role);
    //   if (role == "doctor" && this.id == 'Doctor') {
    //     alert(role + "---" + this.id);
    //     console.log("doctor logged");
    //     this.userAuthService.setToken(data.token);
    //     this.userAuthService.loggedIn = true;
    //     this.router.navigate(['/doctor']);
    //   } else if (role == "patient" && this.id == 'Patient') {
    //     alert(role + "---" + this.id);
    //     console.log("patient logged");
    //     this.userAuthService.setToken(data.token);
    //     this.userAuthService.loggedIn = true;
    //     this.router.navigate(['/patient']);
    //   } else if (role == "Admin" || this.id == 'Admin') {
    //     alert(role + "---" + this.id);
    //     console.log("admin logged");
    //     this.userAuthService.loggedIn = true;
    //     this.userAuthService.setToken(data.token);
    //     this.router.navigate(['/admin']);
    //   } else {
    //     alert(role + "---" + this.id);
    //     this.isLoginValid = false;
    //     this.error = "Invalid Username/Password";
    //   }
    // },
    
     
        
    //       // console.log("admin logged");
    //       // this.userAuthService.loggedIn = true;
    //       // this.userAuthService.setToken(data.token);
    //       // this.router.navigate(['/admin']);
    //       // this.isLoginValid = false;
    //       // this.error = "Invalid Username/Password";
        
    
    //   (error) => {
    //     console.log("error");
    //     this.isLoginValid = false;
    //     if (error.status == 401)
    //       this.error = "Invalid Username/Password";
    //   }
    // );
  

