﻿using System;
using System.Collections.Generic;

namespace MedicareEF.Models
{
    public partial class Patient
    {
        public int PtId { get; set; }
        public string PtFirstName { get; set; }
        public string PtLastName { get; set; }
        public short PtAge { get; set; }
        public string PtGender { get; set; }
        public DateTime? PtDob { get; set; }
        public long PtContactNumber { get; set; }
        public long? PtAltNumber { get; set; }
        public string PtEmail { get; set; }
        public string PtPassword { get; set; }
        public string PtAddress1 { get; set; }
        public string PtAddress2 { get; set; }
        public string PtCity { get; set; }
        public string PtState { get; set; }
        public string PtZipCode { get; set; }
    }
}
