export interface User {
    patientId:number;
    firstName:String;
    password:String;
    role:String;
    EmailId:string;
    phoneNumber:number;
    lastName:string;
    // us_admin_approved:boolean;
}