import { Component, OnInit, Inject } from '@angular/core';
import { Doctor } from 'src/app/doctor/doctor/doctor';
import { DoctorService } from 'src/app/service/doctor.service';
import { PatientService } from 'src/app/service/patient.service';
import { Patient } from 'src/app/patient/patient/patient';
import { Bookdoc } from 'src/app/patient/bookdoc';
import { User } from 'src/app/site/User';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Variable } from '@angular/compiler/src/render3/r3_ast';
import { Observable } from 'rxjs';
import { admindetails } from '../admindetails';
import { AuthenticationService } from 'src/app/service/authentication.service';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { FormGroup, FormBuilder, Form } from '@angular/forms';
import { TestReport } from '../TestReport';
import { ExcelService } from 'src/app/excel.service';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  doctors: Doctor[];
  patients: Bookdoc[];
  testreports: TestReport[];
  AllpatientDetails:User[];
  AlldoctorDetails:Doctor[];
  
   i:number;
   id:any;
   commentForm:FormGroup;

   userPatients:Observable<any[]>;
  userDoctors:Observable<any[]>;
  Testreports:TestReport[]
  admindetails:Observable<any[]>;

  singleadmindetails:admindetails;
  singlepatientDetails:any
  singledoctorDetails:any;
  singletestreportlist:TestReport;

  isApprove:boolean=false;
  view:boolean=false;
  isNotifiedP:boolean=false;
  isNotifiedD:boolean=false;
  isNotifiedR:boolean=false;
  isViewed:boolean=false;
  isDoctorViewed:boolean=false;
      isNew=false; 
     isPatient=false;
    updatePatient:boolean=false;
    updateNew:boolean=false;
    deletePatient:boolean=false;
    deleteNew1:boolean=false;
    iscomments:boolean=false;
    ismodaltrue: boolean=false;
    IsReportViewed:boolean=false;
    isNotification
    isNotifyClicked: boolean


message:any;
  Formvisible: boolean=false;
  constructor( private excelService:ExcelService,private doctorService: DoctorService, private patientService: PatientService,private router: Router,private route: ActivatedRoute,private adminservice: AuthenticationService,private userauthservice:UserAuthService, private fb:FormBuilder) {
 
    console.log("---------------");
    this.isPatient=false;
    this.isNew=false;
    this.isApprove=false;

   }
  
  ngOnInit() {
    this.isNotifyClicked = false
    this.userPatients = this.patientService.getAllUserPatients()
    this.userDoctors=this.doctorService.getAllUserDoctors();
    this.commentForm = this.fb.group({
      reject: [''],
    })
   this.patientService.getReports().subscribe(
    data => {
      this.Testreports = data
      console.log(this.Testreports);
    }
   )
   


  }

show()
{
  this.ismodaltrue=true;
}

onSubmit()
{
  console.log(this.commentForm.value);
}
hide()
{
  this.ismodaltrue=false;
}
ViewNotification()
{
  if(this.isNotifyClicked == true)
  {
    this.isNotifyClicked = false
  }
  else if(this.isNotifyClicked == false)
  {
    this.isNotifyClicked = true
  }
 this. isNotifiedP=true;
  this.isNotifiedD=true;
  this.isNotifiedR=true;
  this.IsReportViewed=false;
  this.Formvisible=false;
  this.isPatient=false;
  this.isNew=false;
  this.isApprove=false;
  this.isDoctorViewed=false;
  this.IsReportViewed=false;
  this.Formvisible=false;
this.isViewed=false;
}

showpatients(){
  this.isPatient=true;
  this.isNew=false;
  this.isApprove=false;
  this.isDoctorViewed=false;
  this.IsReportViewed=false;
  this.Formvisible=false;
}

showNew()
{
  this.isNew=true;
  this.isPatient=false;
  this.isApprove=false;
  this.isViewed=false;
  this.IsReportViewed=false;
  this.Formvisible=false;
}

showReport()
{
  this.isNew=false;
  this.isPatient=false;
  this.isApprove=true;
  this.IsReportViewed=false;
  this.Formvisible=false;
  this.isDoctorViewed=false;
  this.Formvisible=false;
}

Admindetails()
{
  return this.userauthservice.loggedInUser  
}
Viewpatient(id:number)
{
  this.Formvisible=false;
  console.log(id);
  this.isViewed=true;
  this.IsReportViewed=false;
    this.patientService.getAllUserPatientsDetails(id).subscribe(data=>{
     
      console.log(data)
      this.singlepatientDetails=data[0]
      console.log("after clicking");
      console.log(this.userPatients);
 
      console.log(this.singlepatientDetails);
      if(this.userPatients!=null){
      console.log(this.singlepatientDetails);
      }
      else{
        console.log("No data");
      }
    });
  setTimeout(() => {
    this.updateNew = true;
  }, 1000);
}
ViewDoctor(id:number)
{
  this.Formvisible=false;
     console.log(id);
     this.isDoctorViewed=true;
     this.IsReportViewed=false;
     this.doctorService.getAllDoctorDetails(id).subscribe(data=>{
    
      console.log(data);
      this.singledoctorDetails=data[0];
      console.log(this.singledoctorDetails);
       if(this.userDoctors!=null){
      console.log(this.userDoctors);
      }
      else{
        console.log("No data");
      }
    });

  setTimeout(() => {
    this.updateNew = true;
  }, 1000);
}
viewReport(patientid:number)

{this.IsReportViewed=true;
  this.Formvisible=false;
console.log(patientid);

this.patientService.getReportDetails(patientid).subscribe(data=>{
 
  this.singletestreportlist=data;
  console.log(this.singletestreportlist);
})
;}
exportAsXLSX():void {
    this.excelService.exportAsExcelFile(this.Testreports, 'sample');
  }
  

  


acceptNewPatient(id:number)
{
  this.Formvisible=false;
  this.isViewed=false;
  this.IsReportViewed=false;
  console.log("Accept Method Activated");
   console.log(id);
   this.patientService.AcceptPatients(id).subscribe(
     data => {
      console.log(JSON.parse(JSON.stringify(data))['message'])
      this.userPatients = this.patientService.getAllUserPatients()
     }
   )

}
acceptNewDoctor(id:number)
{
  this.Formvisible=false;
  this.isDoctorViewed=false;
  this.IsReportViewed=false;
  console.log("Accept Method Activated");
   console.log(id);
   this.doctorService.approveDoctor(id).subscribe(
     data => {
      console.log(JSON.parse(JSON.stringify(data))['message'])
      this.userDoctors = this.doctorService.getAllUserDoctors()
     }
   )

}

deleteNewPatient(id:number)
{
  
  this.isViewed=false;
  this.IsReportViewed=false;
  console.log("Delete Method Activated");
  this.message = this.commentForm.get('reject').value
  console.log(id);
  this.patientService.deleteNewPatient(id,this.message).subscribe(
    data => {
     console.log(JSON.parse(JSON.stringify(data))['message'])
     this.userPatients = this.patientService.getAllUserPatients()
    }
  )
}

reject()
{
  this.Formvisible=true;
}
deleteNewDoctor(id:number)
{
 
  console.log(id);
  this.isDoctorViewed=false;
  this.IsReportViewed=false;
  this.message = this.commentForm.get('reject').value
  console.log(this.message)
  console.log("Delete Method Activated");
  console.log(id);
  this.doctorService.rejectDoctor(id,this.message).subscribe(
    data => {
     console.log(JSON.parse(JSON.stringify(data))['message'])
     this.userDoctors = this.doctorService.getAllUserDoctors()

  }
    
  )

}

pendingNewDoctor(id:number)
{
  this.Formvisible=false;
  this.isDoctorViewed=false;
  this.IsReportViewed=false;
  console.log("Pending method Activated");
  console.log(id);
  this.doctorService.PenidngDoctor(id).subscribe(
    data => {
     console.log(JSON.parse(JSON.stringify(data))['message'])
     this.userDoctors = this.doctorService.getAllUserDoctors()
    }
  )

}

}



