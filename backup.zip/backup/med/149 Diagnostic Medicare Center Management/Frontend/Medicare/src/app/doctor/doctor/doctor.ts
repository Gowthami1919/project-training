export interface Doctor {
    id: number;
    doctorId: number;
    firstName: string;
    lastName: string;
    age: number;
    gender: string;
    dateOfBirth: string;
    contactNumber: number;
    altContactNumber: number;
    emailId: string;
    password: string;
    addressLine1: string;
    city: string;
    state: string;
    zipCode: number;
    degree:string;
    speciality:string;
    workHours:string;
    hospitalName:string;
    role:string;
}