﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MedicareEF.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MedicareEF.Controllers
{
    [EnableCors("MedicarePolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorController : ControllerBase
    {
        MedicareContext Medicontext = new MedicareContext();
        Doctor Dt = new Doctor();
        [HttpPost]
        public IActionResult Create([FromBody] Doctor doc)
        {
            Dt.DocUsername = doc.DocUsername;
            Dt.FirstName = doc.FirstName;
            Dt.LastName = doc.LastName;
            Dt.Age = doc.Age;
            Dt.Gender = doc.Gender;
            Dt.DateOfBirth = doc.DateOfBirth;
            Dt.ContactNumber = doc.ContactNumber;
            Dt.AltNumber = doc.AltNumber;
            Dt.EmailId = doc.EmailId;
            Dt.Password = doc.Password;
            Dt.AddressLine1 = doc.AddressLine1;
            Dt.AddressLine2 = doc.AddressLine2;
            Dt.City = doc.City;
            Dt.State = doc.State;
            Dt.Zipcode = doc.Zipcode;
            Dt.Degree = doc.Degree;
            Dt.Speciality = doc.Speciality;
            Dt.WorkHours = doc.WorkHours;
            Dt.HospitalName = doc.HospitalName;
            Dt.Role = "Doctor";
            Dt.Permission = "No";
            Dt.Status = "Pending";
            Dt.DocAdComments = "";
            Medicontext.Doctor.Add(Dt);
            Medicontext.SaveChanges();
            return Ok("Doctor Registration Successful");
        }
        [Route("login/{UserName}/{Password}")]
        [HttpPost("{UserName}/{Password}")]
        public IActionResult Post(string UserName, string Password)
        {
            string perm = "Yes";
            string stat = "Approved";
            var menu = from me in Medicontext.Doctor
                       where (me.DocUsername == UserName) && (me.Password == Password) && me.Permission == perm && me.Status == stat
                       select new { me.DoctorId, me.FirstName, me.LastName, me.Gender, me.EmailId, me.Role, me.DocUsername };
            var rejected = Medicontext.Doctor.Where(ad => ad.DocUsername == UserName && ad.Password == Password && ad.Status=="Rejected").FirstOrDefault();

            var item = Medicontext.Doctor.Where(ad => ad.DocUsername == UserName && ad.Password == Password && ad.Permission == perm && ad.Status == stat).FirstOrDefault(); ;
            if (item != null)
                return Ok(new { message = "Logined succefully", user = menu });
            else
                return Ok(new { message = "Logined invalid", reject = rejected });
        }

        [Route("checkUsername/{Username}")]
        [HttpGet("{Username}")]
        public ActionResult EmailExist(string Username)
        {
            var user = Medicontext.Doctor.Where(un => un.DocUsername == Username).FirstOrDefault();
            if (user == null)
                return Ok(new { status = "No such username" });
            else
                return Ok(new { status = "username already exist" });
        }

        [Route("Addservice/{ServiceId}/{DoctorId}")]
        [HttpPost("{ServiceId}/{DoctorId}")]
        public IActionResult AddServiceToDoctor(int ServiceId, int DoctorId)
        {
            DoctorService Dt_service = new DoctorService();
            var services = Medicontext.DoctorService.Where(doctor => doctor.ServiceId == ServiceId && doctor.DocId == DoctorId).FirstOrDefault();
            if (services != null)
            {
                return Ok(new { message = "Already Added" });
            }

            Dt_service.DocId = DoctorId;
            Dt_service.ServiceId = ServiceId;
            Medicontext.DoctorService.Add(Dt_service);
            Medicontext.SaveChanges();
            return Ok(new { message = "Updated" });
        }

        [Route("DoctorService")]
        [HttpGet]
        public IActionResult DoctorService()
        {

            return Ok(Medicontext.MediServices);

        }
        [Route("AddServiceToDoctor/{Service_Id}/{Doctor_Id}")]
        [HttpPost("{Service_Id}/{Doctor_Id}")]
        public IActionResult AddServiceDoctor(int Service_Id, int Doctor_Id)
        {
            DoctorService Dt_service = new DoctorService();
            var services = Medicontext.DoctorService.Where(doctor => doctor.ServiceId == Service_Id && doctor.DocId == Doctor_Id).FirstOrDefault();
            if (services != null)
            {
                return Ok(new { message = "Already Added" });
            }

            Dt_service.DocId = Doctor_Id;
            Dt_service.ServiceId = Service_Id;
            Medicontext.DoctorService.Add(Dt_service);
            Medicontext.SaveChanges();
            return Ok(new { message = "Updated" });
        }
        [Route("PatientRequest/{Doctor_Id}")]
        [HttpGet("{Doctor_Id}")]


        public IActionResult PatientRequest(int Doctor_Id)
        {
            var patients = from me in Medicontext.Bookappointments
                           where me.AppoDate > DateTime.Now && me.DoctorId == Doctor_Id && me.DoctorApproval == "no"
                           select new { me.Patient.FirstName, me.PatientId, me.Service.MdService, me.BookappointmentId, me.Patient.ContactNumber, me.AppointmentStatus, me.AppoDate,me.PatientName };
            return Ok(patients);
        }

        [Route("DoctorReject/{Book_Primary_Id}")]
        [HttpPut("{Book_Primary_Id}")]

        public IActionResult DoctorAppointementReject(int Book_Primary_Id)
        {
            var booking_Reject = Medicontext.Bookappointments.Where(book => book.BookappointmentId == Book_Primary_Id).FirstOrDefault();
            booking_Reject.DoctorApproval = "Pending";
            booking_Reject.AppointmentStatus = "Pending";
            Medicontext.Bookappointments.Update(booking_Reject);
            Medicontext.SaveChanges();
            return Ok(booking_Reject);
        }

        [Route("DoctorApproval/{book_appiontment_Id}")]
        [HttpPut("{book_appiontment_Id}")]
        public IActionResult DoctorApproval(int book_appiontment_Id)
        {
            var patient = Medicontext.Bookappointments.Where(pat => pat.BookappointmentId == book_appiontment_Id).FirstOrDefault();
            patient.DoctorApproval = "yes";
            patient.AppointmentStatus = "approved";
            Medicontext.Bookappointments.Update(patient);
            Medicontext.SaveChanges();
            return Ok(patient);

        }

        [Route("PatientReports/{Doctor_Id}")]
        [HttpGet("{Doctor_Id}")]
        public IActionResult PatientReports(int Doctor_Id)
        {
            var patients = from me in Medicontext.Bookappointments
                           where me.DoctorApproval == "yes" && me.DoctorId == Doctor_Id
                           select new { me.Username, me.BookappointmentId, me.AppoDate, me.ServiceId, me.PatientId,me.PatientName };
            return Ok(patients);
        }


        [Route("PostTestResult")]
        [HttpPost]
        public IActionResult PostUpdateTest([FromBody]MedicalTests medicaltest)
        {

            MedicalTests medi = new MedicalTests();

            medi.PatientId = medicaltest.PatientId;
            medi.DoctorId = medicaltest.DoctorId;
            medi.ServiceId = medicaltest.ServiceId;
            medi.TestResultDate = medicaltest.TestResultDate;
            medi.Diag1ActualValue = medicaltest.Diag1ActualValue;
            medi.Diag1NormalRange = medicaltest.Diag1NormalRange;
            medi.Diag2ActualValue = medicaltest.Diag2ActualValue;
            medi.Diag2NormalRange = medicaltest.Diag2NormalRange;
            medi.Diag3ActualValue = medicaltest.Diag3ActualValue;
            medi.Diag3NormalRange = medicaltest.Diag3NormalRange;
            medi.DoctorComments = medicaltest.DoctorComments;
            medi.AdminApproval = "No";
            medi.DoctorViewed = "yes";
            medi.PtRequestRaised = "No";
            Medicontext.MedicalTests.Add(medi);
            Medicontext.SaveChanges();
            return Ok(new { message = "Updated" });


        }
        [Route("GetAllMedicalTests")]
        [HttpGet]
        public IActionResult GetAllMedicalTests()
        {
            return Ok(Medicontext.MedicalTests);
        }

        [Route("GetAllServices/{Doctor_Id}")]
        [HttpGet("{Doctor_Id}")]
        public IActionResult GetAllServices(int Doctor_Id)

        {
            var services = from ser in Medicontext.DoctorService
                           where ser.DocId == Doctor_Id 
                           select new { ser.Service.MdService, ser.Service.MdId, ser.Service.MdAmount };
            return Ok(services);
        }


        [Route("DeleteDoctorServices/{Doctor_Id}/{Service_Id}")]
        [HttpDelete("{Doctor_Id}/{Service_Id}")]
        public IActionResult DeleteService(int Doctor_Id, int Service_Id)
        {

            var service = Medicontext.DoctorService.Where(ser => ser.DocId == Doctor_Id && ser.ServiceId == Service_Id).FirstOrDefault();
            Medicontext.DoctorService.Remove(service);
            Medicontext.SaveChanges();
            return Ok("Deleted");

        }
    }
}