﻿using System;
using System.Collections.Generic;

namespace MedicareEF.Models
{
    public partial class Doctor
    {
        public int DtId { get; set; }
        public string DtFirstName { get; set; }
        public string DtLastName { get; set; }
        public short DtAge { get; set; }
        public string DtGender { get; set; }
        public DateTime? DtDob { get; set; }
        public long DtContactNumber { get; set; }
        public long? DtAltNumber { get; set; }
        public string DtEmailId { get; set; }
        public string DtPassword { get; set; }
        public string DtAddressLine1 { get; set; }
        public string DtAddressLine2 { get; set; }
        public string DtCity { get; set; }
        public string DtState { get; set; }
        public long DtZipcode { get; set; }
        public string DtDegree { get; set; }
        public string DtSpeciality { get; set; }
        public string DtWorkHours { get; set; }
        public string DtHospitalName { get; set; }
        public int DtMdId { get; set; }

        public virtual MediServices DtMd { get; set; }
    }
}
