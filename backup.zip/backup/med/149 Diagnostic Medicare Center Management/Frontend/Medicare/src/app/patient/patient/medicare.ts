export interface Medicare{
    ms_id:number;
    ms_name:String;
    ms_description:String;
    ms_amount:number;
    ms_image_url:String;
}